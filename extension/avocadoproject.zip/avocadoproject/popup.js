var discount = ['a','and','the','to','an','it','is','in','if','of','this','that','for','nbsp','gt','lt','http','on','ad','was','px','pt','about','typeof','by','ago','jump'];


document.addEventListener('DOMContentLoaded', function(){
    //TODO:do something 
    var word_array = [
        {text: "Nolan", weight: 20},
        {text: "Miller", weight: 15},
        {text: "Andrew", weight: 10}
    ];
//    $("#map").jQCloud(word_array);
    
    chrome.runtime.sendMessage({type: "pull",data: "nothing"},function(response){
        var words = [];
        for(word in response.data){
            if(discount.indexOf(word)==-1&&word.length>1)
                words.push({text:word, weight:response.data[word],link:"#",handlers:{click: function(){
                    console.log("clicked!");
                }}});
                //,handlers: {click: function() { alert("it worked for" ); }});
        }
        $("#map").jQCloud(words);
    });



});
