histo.getHistDoc(document,function(array){
    
    chrome.runtime.sendMessage({type: "push", data: array, url: document.URL, title: document.title}, function(response) {
          console.log(response.data);
    });
    
    console.log(array);

 //    chrome.runtime.sendMessage({type: "weight",data: array}, function(response) {
	//       console.log(response.data);
	// });
    
});
        //histo.getHistUrl("http://espn.go.com/",function(array){console.log(array);});

//chrome.runtime.sendMessage({greeting: "hello"}, function(response) {
//      console.log(response);
//});

console.log("here are the links");
console.log(document.links[0]);

