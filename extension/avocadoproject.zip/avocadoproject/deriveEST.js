//deriveEST.js

var mStandardDeviation = {};

function deriveEST(){

	// Check for the various File API support.
	if (window.File && window.FileReader && window.FileList && window.Blob) {
	  // Great success! All the File APIs are supported.
	  // alert("success");
	} else {
	  alert('The File APIs are not fully supported in this browser.');
	}

	var siteListX = 
	"1	google.com \
	2	youtube.com \
	3	Hidden profile \
	4	en.wikipedia.org/wiki/Main_Page";

	var siteList = 
	"1	google.com \
	2	youtube.com \
	3	ebay.com \
	4	facebook.com \
	5	msn.com \
	6	amazon.com \
	7	twitter.com \
	8	wordpress.com \
	9	microsoft.com \
	11	yelp.com \
	13	answers.com \
	14	buzzfeed.com \
	15	huffingtonpost.com \
	16	pinterest.com \
	17	wikipedia.org \
	18	live.com \
	19	bing.com \
	20	linkedin.com \
	21	blogger.com \
	25	adobe.com \
	26	wikia.com \
	27	nbcnews.com \
	28	weather.com \
	29	bleacherreport.com \
	30	craigslist.org";

	//generate site array
	// siteList = siteList.replace("Hidden profile", "invalidURL");
	var pattern = new RegExp(/[ \n\t]+/g);
	var siteList = siteList.split(pattern);	

	var sites = new Array();
	var numIncorrectURL = 0;
	var index = 0;
	for (var i = 0; i < siteList.length; i++){
		if (i% 2 == 1){
			// if (!(siteList[i] === "invalidURL")){
				sites[index++] = siteList[i];
			// }
		}
	}
	// sites is now an array of site strings
	// console.log(siteList);
	console.log(sites);

	var errorchecking = true;
	numSites = sites.length;
	console.log("numSites: " + numSites);

	var summationHistogram = {};
	var numWordsOnAllSites = 0;
	var numHisto = 0;
	for (var iSite = 0; iSite < numSites; iSite++){

        histo.getHistUrl("http://" + sites[iSite],function(array){
        	var newHisto = array;
        	histo.hist = {};
        	// console.log(newHisto);
        	
			if (numHisto == 0){
				summationHistogram = newHisto;
				for (var iWord in newHisto){
					numWordsOnAllSites += newHisto[iWord];
				}
			}
			else{
			//add new histo to existing
			//if not there, returns "undefined"
				for (var iWord in newHisto){
					if (isNaN(summationHistogram[iWord])){
						summationHistogram[iWord] = newHisto[iWord];
						// console.log("summationHistogram[" + iWord + "]: " + summationHistogram[iWord]);
					}else{
						summationHistogram[iWord] += newHisto[iWord];
						// console.log("summationHistogram[" + iWord + "]: " + summationHistogram[iWord]);
					}
					numWordsOnAllSites += newHisto[iWord];
				}
			}

			numHisto++;
        	if (numHisto == numSites){ //last time (1x)
        		numHisto = 0; //reset
        		//now summationHistogram and numWordsOnAllSites should be correct

				//solve for expectedWordScore
				var expectedWordScore = {};
				summationHistogramSize = 0;
				for (var iWord in summationHistogram){ summationHistogramSize++;}
				// console.log("summationHistogram num words: " + summationHistogramSize);
				// console.log("summationHistogram total words: " + numWordsOnAllSites);
				for (var iWord in summationHistogram){
					expectedWordScore[iWord] = summationHistogram[iWord] / numWordsOnAllSites;
					// console.log(expectedWordScore);
				}
				// console.log(expectedWordScore);

				for (var iSite = 0; iSite < numSites; iSite++){
					histo.getHistUrl("http://" + sites[iSite],function(array){
			        	var newHisto = array;
			        	histo.hist = {};

						//find total num words
						var numWordsOnSite = 0;
						for (var iWord in newHisto){
							numWordsOnSite += newHisto[iWord];
						}
						// console.log("Number of total words on site: " + numWordsOnSite);
						//now numWordsOnSite has the number of words on that site

						//find wordScore (percentage) and expected score
						for (var iWord in newHisto){
							if (numWordsOnSite == 0){
								console.log("HUGE PROBLEM");
							}
							var wordScore = newHisto[iWord] / numWordsOnSite;
							var wordScoreDeviation = Math.abs(wordScore - expectedWordScore[iWord]);
							wordScoreDeviation = 1/wordScoreDeviation;
							if (isNaN(mStandardDeviation[iWord])){
								mStandardDeviation[iWord] = wordScoreDeviation;
							}else{
								mStandardDeviation[iWord] += wordScoreDeviation;
							}
						}
						
						numHisto++;
						if (numHisto == numSites){
							//last site call
							mStandardDeviation = expectedWordScore;
							for (var iWord in mStandardDeviation){
								mStandardDeviation[iWord] = 1/mStandardDeviation[iWord];
							}

							console.log("Word Weight:");
							console.log(mStandardDeviation);
						}
					
					// now mStandardDeviation is calculated!

					// return mStandardDeviation to server TODO

					});
				}

        	}
        });
	}

}

// var opt = {
//   type: "basic",
//   title: "Primary Title",
//   message: "Primary message to display",
//   iconUrl: "url_to_small_icon"
// }

// chrome.notifications.create(string notificationId, opt, function callback);


// var notification = webkitNotifications.createNotification(
//   'avocado.jpg',  // icon url - can be relative
//   'Hello!',  // notification title
//   'Lorem ipsum...'  // notification body text
// );

// // Then show the notification.
// notification.show();

