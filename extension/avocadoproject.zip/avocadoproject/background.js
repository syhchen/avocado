deriveEST();

var hist = {};
var url;
var title;

chrome.runtime.onMessage.addListener(
        function(request, sender, sendResponse) {
        if (request.type == "pull"){
            console.log("pulling");
            sendResponse({data: hist});
            console.log("sending: "+hist);
        }
        else if (request.type == "push"){
            console.log("pushing");
            hist = request.data;
            url = request.url;
            title = request.title;
            console.log("URL: " + url);
            console.log("Title: " + title);
            getKeywords();
            sendResponse({KW: keywords});
        }
        });

var keywords = {};
function getKeywords(){
    for (var iWord in hist){
        if (isNaN(mStandardDeviation[iWord])){

        }else{
            keywords[iWord] = hist[iWord] * mStandardDeviation[iWord];
        }
    }
    console.log(keywords);

    var sortedKeywords = [];
    var highestScore = 0;
    var highestWord = "";

    //get top 20 keywords
    for (var i = 0; i < 20; i++){
        for (var iWord in keywords){
            if (keywords[iWord] > highestScore){
                highestScore = keywords[iWord];
                highestWord = iWord;
            }
        }
        keywords[highestWord] = 0;
        highestScore = 0;
        sortedKeywords[i] = highestWord;
    }

    console.log("sortedKeywords: ");
    console.log(sortedKeywords);


    //create site profile
    var siteProfile = {
        url: url,
        title: title,
        keywords: sortedKeywords
    }
    // siteProfile["url"] = url;
    // siteProfile["title"] = title;
    // siteProfile["keywords"] = sortedKeywords;

    //send to database
    var sites = [];
    getRecommendations(siteProfile, function(sites) {
        // console.log(sites);

        var recommendedURL = "theavocadoproject.org";

        //sort sites
        var highestWeight = 0;
        for (var iSite in sites){
            // console.log("Site: ");
            // console.log(sites[iSite]);
            if (sites[iSite].weight > highestWeight && sites[iSite].weight < 1 && sites[iSite].url.match(/google/g) == null){
                highestWeight = sites[iSite].weight;
                recommendedURL = sites[iSite].url;
            }
        }

        console.log("Recommended URL attempt: " + sites[0].url);

        var notification = webkitNotifications.createNotification(
          'http://upload.wikimedia.org/wikipedia/commons/1/1d/Avocado.jpeg',  // icon url - can be relative
          'Recommended Site:',  // notification title
          recommendedURL  // notification body text
        );

        notification.addEventListener('click', function() {
            notification.cancel();
            window.open(recommendedURL);
        });

        // Then show the notification.
        notification.show();
        setTimeout(function(){
            notification.cancel();
        }, 5000);
    });




    
}



//-----------------------------------------------------------

// Puts the given page in the database and ensures any keyword indices are maintained
function logPage(site, callback) {
    var fb = new Firebase('https://guac.firebaseio.com'),
        page_clean_url = clean_url(site.url);
 
    fb.child('pages/' + page_clean_url).once('value', function(snapshot) {
        var data = snapshot.val(),
            toAdd, toRemove;
 
        // Figure out which keywords we need to add and remove.
        if (data) {
            toAdd    = _.difference(site.keywords, data.keywords),
            toRemove = _.difference(data.keywords, site.keywords);
        } else {
            toAdd    = site.keywords,
            toRemove = [];
        }
 
        toAdd.forEach(function(keyword) {
            addPageToKeyword(page_clean_url, site.url, keyword);
        });
 
        toRemove.forEach(function(keyword) {
            removePageFromKeyword(page_clean_url, keyword);
        });

        // console.log(site);
 
        fb.child('pages/' + page_clean_url).update(site, callback);
    });
 
    function addPageToKeyword(p_clean_url, real_url, keyword) {
        fb.child('keywords/' +  keyword + '/sites/' + p_clean_url).set(real_url);
    }
 
    function removePageFromKeyword(p_clean_url, keyword) {
        fb.child('keywords/' +  keyword + '/sites/' + p_clean_url).set(null);
    }
}
 
// returns array of objects: 
// [{
//     url: String,
//     weight: Number <-- fraction of keywords for original site that this site matched
// },
// etc...
// ]
function getRecommendations(site, callback) {
    var fb = new Firebase('https://guac.firebaseio.com');
 
    // This callback technically isn't guaranteed to execute after updating
    // keywords when logging the page, but it shouldn't be a huge issue.
    logPage(site, reallyGetRecommendations);
 
    function reallyGetRecommendations() {
        fb.child('keywords').once('value', function(snapshot) {
            var keywords = snapshot.val(),
                selected_sites = [];
 
            site.keywords.forEach(function(key) {
                selected_sites = selected_sites.concat(_.values(keywords[key].sites))
            })
 
            selected_sites = _.countBy(selected_sites)
            selected_sites = _.pairs(selected_sites).map(function(d) {
                return {
                    url: d[0],
                    weight: d[1]*1.0/site.keywords.length
                }
            })
 
            if (callback) callback(selected_sites)
        })
    }
}
 
function clean_url(url) {
    return url.replace(/.*?:\/\//g,"").replace(/\.|\/|\#|\$|\[|\]/g,'-');
}
 
// // Example usage:
 
// // Make site profile
// site_profile = {
//     url: 'https://google.com/home/index.php?pid=23',
//     title: 'Google',
//     keywords: [
//         'search',
//         'internet',
//         'wow',
//         'dog'
//     ]
// }
 
// getRecommendations(site_profile, function(sites) {
//     console.log(sites)
// })