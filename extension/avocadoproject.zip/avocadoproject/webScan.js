function logWord(st,w,hist){
    if(typeof st == 'string'&&typeof w == 'number'){
        if(typeof hist[st] == 'undefined'){
            hist[st] = 0;
        }
        hist[st] +=w;
    }
}
function displayHist(hist){
    var ret = "";
    for(word in this.hist){
        ret+=word+"  :  "+hist[word]+"\n";
    }
    alert(ret);
}

function globString(st){
    return st.toLowerCase().match(/[a-zA-Z]+/g);
}

function logString(st,w,hist){
    var par = globString(st);
    for(word in par){
        logWord(par[word],w,hist);
    }
}
function docHist(doc, histObj){
            var dat = doc.getElementsByTagName("meta");
            for(var i = 0;i<dat.length;i++){
                var s = dat[i].getAttribute("name");
                if(s!==null && (s.indexOf("keywords")!==-1)){
                    logString(dat[i].getAttribute("content"),histObj.K_DESC,histObj.hist);
                }
                if(s!==null && s.indexOf("description")!==-1){
                    logString(dat[i].getAttribute("content"),histObj.K_DESC,histObj.hist);
                }
            }
            for(sel in histObj.K_SELECTS){
                var set = doc.getElementsByTagName(sel);
                var concat = "";
                for (var i = 0;i<set.length;i++){
                    concat+=set[i].innerHTML+" ";
                }
                var theText = concat.replace(/<[^>]*>/g, "");
                    if(typeof theText == "string"){
                        //theText = theText.replace(/(<([^>]+)>)/ig,"");
                        logString(theText,histObj.K_SELECTS[sel],histObj.hist);
                    }
            }
            for(word in histObj.hist){
                if(histObj.hist[word] < 1)
                    delete histObj.hist[word];
            }

            return histObj.hist;
            //none of this is what we want anymore.
            var word_array = [];
            for(word in histObj.hist){
                if(typeof word == "string"){
                    word_array.push({text: word, weight: histObj.hist[word], link: "test.html"});
                }
            }
            return word_array;
        }
function downloadDoc(url, callback){
                var xhr = new XMLHttpRequest();
                xhr.open("GET", url,true);
                xhr.onload = function (){
                    parser = new DOMParser();
                    doc = parser.parseFromString(this.responseText, "text/html");
                    callback(doc);
                }
                xhr.send(null);
}

var histo = {
K_DESC: 5,
        K_KEYS: 10,
        K_SELECTS: {"h1":3,"h2":3,"h3":2,"h4":2,"h5":2,"p":1,"div":1,"body":1,"script":-2},
        hist: {},

        getHistDoc: function(doc,callback){
            callback(docHist(doc,this));
        },
        getHistUrl: function(url,callback){
            thing=this;
                downloadDoc(url,function(doc){
                    var i = 0;
                    callback(docHist(doc, thing));
                });
            }
};
